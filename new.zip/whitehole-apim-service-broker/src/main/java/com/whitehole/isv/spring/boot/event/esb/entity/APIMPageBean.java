package com.whitehole.isv.spring.boot.event.esb.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by zijian on 10/10/16.
 */
public class APIMPageBean<T> {


	private String previous;
    private int count;
    private String next;
    private List<T> list;

    @JsonCreator
    public APIMPageBean(@JsonProperty("list") List<T> list,
                      @JsonProperty("previous") String previous,
                      @JsonProperty("next") String next,
                      @JsonProperty("count") int count) {
        this.previous = previous;
        this.next = next;
        this.list = list;
        this.count = count;
    }

    /**
	 * @return the previous
	 */
	public String getPrevious() {
		return previous;
	}

	/**
	 * @param previous the previous to set
	 */
	public void setPrevious(String previous) {
		this.previous = previous;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the next
	 */
	public String getNext() {
		return next;
	}

	/**
	 * @param next the next to set
	 */
	public void setNext(String next) {
		this.next = next;
	}

	/**
	 * @return the list
	 */
	public List<T> getList() {
		return list;
	}

	/**
	 * @param list the list to set
	 */
	public void setList(List<T> list) {
		this.list = list;
	}

}
