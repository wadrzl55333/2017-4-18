package com.whitehole.isv.spring.boot.event.esb.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider;

/**
 * Created by zijian on 10/11/16.
 */
public class RestClientUtils {


    public static HttpEntity getEntityWithAuth() {
        return new HttpEntity<>(getAuthHttpHeaders());
    }

    public static HttpEntity getEntityWithBody(Object body){
        return new HttpEntity(body, getAuthHttpHeaders());
    }

    private static HttpHeaders getAuthHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
        return headers;
    }


}
