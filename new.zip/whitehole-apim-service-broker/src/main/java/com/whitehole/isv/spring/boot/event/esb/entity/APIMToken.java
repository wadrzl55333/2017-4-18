package com.whitehole.isv.spring.boot.event.esb.entity;

public class APIMToken {

	private int validityTime;
	private String accessToken;
	private String[] tokenScopes;
	/**
	 * @return the validityTime
	 */
	public int getValidityTime() {
		return validityTime;
	}
	/**
	 * @param validityTime the validityTime to set
	 */
	public void setValidityTime(int validityTime) {
		this.validityTime = validityTime;
	}
	/**
	 * @return the accessToken
	 */
	public String getAccessToken() {
		return accessToken;
	}
	/**
	 * @param accessToken the accessToken to set
	 */
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	/**
	 * @return the tokenScopes
	 */
	public String[] getTokenScopes() {
		return tokenScopes;
	}
	/**
	 * @param tokenScopes the tokenScopes to set
	 */
	public void setTokenScopes(String[] tokenScopes) {
		this.tokenScopes = tokenScopes;
	}
	
	

}
