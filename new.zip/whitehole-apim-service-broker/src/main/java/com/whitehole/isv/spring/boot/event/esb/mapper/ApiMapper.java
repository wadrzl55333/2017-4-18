package com.whitehole.isv.spring.boot.event.esb.mapper;


import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.transaction.annotation.Transactional;

import com.whitehole.isv.spring.boot.event.esb.entity.AmApi;
import com.whitehole.isv.spring.boot.event.esb.entity.LimitIp;


/**
 * 任务接入接口Mapper
 * Created by sg on 2016/7/8.
 */
@Transactional
public interface ApiMapper {

/**
 * 
 * @param apiIdTo
 * @param applicationIdTo
 * @param createdate
 * @param UUID
 */
    @Insert("INSERT INTO AM_SUBSCRIPTION VALUES(null,'Unlimited',#{apiIdTo},null,#{applicationIdTo},'UNBLOCKED','SUBSCRIBE','admin',#{createdate},null,null,#{UUID})")
    void addSubscription(@Param("apiIdTo") String apiIdTo ,@Param("applicationIdTo") String applicationIdTo,@Param("createdate") Date createdate,@Param("UUID") String UUID);


/**
 * 
 * @param urlPattern
 * @return
 */
    @Select("SELECT api_id as apiId,url_Pattern as urlPattern from AM_API_URL_MAPPING where url_Pattern like #{urlPattern} ")
    List<AmApi> getApiByUrlPattern(@Param("urlPattern") String urlPattern);
 /**
  *    
  * @param projectId
  * @return
  */
    @Select("SELECT application_id from AM_APPLICATION where name = #{projectId} ")
    String getApiIdToByApplicationName(@Param("projectId") String projectId);

    @Select("SELECT context from AM_API where api_id = #{apiIdTo} ")
    String getApiContextByApiId(@Param("apiIdTo") String apiIdTo);
    
    @Select("SELECT api_id as apiId from AM_API where context = #{context}")
    AmApi getApiByContext(@Param("context") String context);


	/**
	 * @param uuid
	 */
    @Delete("Delete from AM_SUBSCRIPTION where UUID = #{UUID}")
    void deleteSubscription(@Param("UUID") String UUID);


	/**
	 * @param service
	 * @param ip
	 */
    @Insert("INSERT INTO ip_limit VALUES(null,#{ipAdress},#{service},'0',#{subscriptionId})")
	void addLimitIp(@Param("service")String service, @Param("ipAdress") String ipAdress, @Param("subscriptionId")String subscriptionId);


	/**
	 * @return
	 */
    @Select("SELECT ID as id ,URL as url ,IP as ip FROM ip_limit where STATUS = '0' ")
	List<LimitIp> getLimitIp();


	/**
	 * @param id
	 */
    @Update("Update ip_limit set STATUS = '1' where id = #{id} ")
	void changeLimitIpStatus(@Param("id") String id);


	/**
	 * @param apiSubId
	 * @return
	 */
    @Select("SELECT ID as id ,URL as url ,IP as ip FROM ip_limit where SUBSCRIPITONID = #{apiSubId} ")
	LimitIp getLimitIpBySubId(@Param("apiSubId")String apiSubId);


	/**
	 * @param apiId
	 * @return
	 */
    @Select("SELECT url_pattern as urlPattern from AM_API_URL_MAPPING where api_id = #{apiId}")
	String getUrlPatternByApiId(@Param("apiId")String apiId);
	
	


	
}
