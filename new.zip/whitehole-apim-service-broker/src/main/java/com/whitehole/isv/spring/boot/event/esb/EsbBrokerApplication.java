package com.whitehole.isv.spring.boot.event.esb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by sg on 2017/7/5.
 */
@SpringBootApplication
@EnableScheduling
public class EsbBrokerApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(EsbBrokerApplication.class, args);        
    }
    
}
