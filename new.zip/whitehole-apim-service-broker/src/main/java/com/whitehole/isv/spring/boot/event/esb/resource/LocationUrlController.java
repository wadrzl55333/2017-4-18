package com.whitehole.isv.spring.boot.event.esb.resource;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.whitehole.isv.spring.boot.event.esb.entity.ResponseObject;
import com.whitehole.isv.spring.boot.event.esb.service.NginxConfigurationService;

/**
 * Created by zijian on 12/9/16.
 * 提供白名单相关接口给支撑平台门户调用
 * 用于支撑平台申请服务时，通知总线nginx修改对应配置，以达到限制IP访问的目的
 */
@RestController
@RequestMapping("/notification/location")
public class LocationUrlController {

    @Autowired
    private NginxConfigurationService nginxConfigurationService;
    private static final int ERROR_STATUS = 500;

    @RequestMapping(method = RequestMethod.POST)
    @ApiOperation(
            value = "新增NGINX映射",
            notes = "当支撑平台门户申请API实例成功时，会触发此方法，用于在NGINX 配置中新增转发映射达到控制IP访问的目的",
            produces = "application/json",
            response = ResponseObject.class)
    public ResponseEntity addLocationUrl(
            @ApiParam(name = "data", value = "在RequestBody中的JSON参数", required = true) @RequestBody Map<String, String> data) {

        //对应 nginx 配置中的location
        String locationUrl = data.get("location");
        //对应 nginx 配置中的 proxy_pass
        String proxyPass = data.get("proxy_pass");
      //对应 nginx 配置中的 allow ip
        String ips = data.get("ips");

        boolean result = nginxConfigurationService.addLocationUrl(locationUrl, proxyPass, ips);
        ResponseObject responseObject = new ResponseObject();
        if (result) {
            responseObject.setMessage("update nginx config success");
        } else {
            responseObject.setStatus(ERROR_STATUS);
            responseObject.setMessage("update nginx config failed");
        }

        return result ? ResponseEntity.ok(responseObject) : ResponseEntity.ok(responseObject);

    }

    @RequestMapping(method = RequestMethod.DELETE)
    @ApiOperation(
            value = "删除NGINX映射",
            notes = "当支撑平台门户删除API实例成功时，会触发此方法，用于在NGINX 配置中删除转发映射",
            produces = "application/json",
            response = ResponseEntity.class)
    public void deleteLocationUrl(@ApiParam(name = "data", value = "在RequestBody中的JSON参数", required = true) Map<String, String> data) {

        //对应 nginx 配置中的location
        String locationUrl = data.get("location");

        nginxConfigurationService.deleteLocationUrl(locationUrl);

    }

}
