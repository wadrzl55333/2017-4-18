package com.whitehole.isv.spring.boot.event.esb.service;

import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_APIRESOURCE_RETRIEVE;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_APPLICATIONS_CREATE;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_APPLICATIONS_DETAILS;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_APPLICATIONS_GENERATE_KEY;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_APPLICATIONS_RETRIEVE;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_MANAGER_ENDPOINT;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_SUBSCRIPTION_ADD;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.API_SUBSCRIPTION_REMOVE;
import static com.whitehole.isv.spring.boot.event.esb.util.RestClientUtils.getEntityWithAuth;
import static com.whitehole.isv.spring.boot.event.esb.util.RestClientUtils.getEntityWithBody;
import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMAPIResource;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMApplication;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMApplicationKey;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMPageBean;
import com.whitehole.isv.spring.boot.event.esb.entity.APIMSubscription;
import com.whitehole.isv.spring.boot.event.esb.util.HttpClientUtil;
import com.whitehole.isv.spring.boot.event.esb.util.JacksonUtil;

/**
 * Created by zijian on 10/10/16.
 */
@Service
public class ApiManagerService {


    private RestTemplate restTemplate = new RestTemplate();
    

    private static Log logger = LogFactory.getLog(ApiManagerService.class);

    public APIMPageBean<APIMApplication> retrieveApplications(String appName) throws Exception{
        APIMPageBean<APIMApplication> result = new APIMPageBean<APIMApplication>(null, "", "", 0) {
        };
//        Map map = new HashMap<String,String>();
//        map.put("Authorization", "Bearer b2fedc6b-2ffc-315c-be53-8e0237b4dd82");
//        ResponseEntity<APIMPageBean<APIMApplication>> response = (ResponseEntity<APIMPageBean<APIMApplication>>) HttpClientUtil.httpClientPostUrl(map, API_MANAGER_ENDPOINT + API_APPLICATIONS_RETRIEVE + "?query=" + appName, null, true);
        String response = HttpClientUtil.doHttpsGet(API_MANAGER_ENDPOINT + API_APPLICATIONS_RETRIEVE + "?query=" + appName, ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
    	if (!StringUtils.isEmpty(response)) {
    		result = JacksonUtil.readValue(response, new TypeReference<APIMPageBean<APIMApplication>>() {});
    	}
        return result;

    }

    public APIMApplication getApplicationDetailsWithAppName(String appId){
    	APIMApplication result = new APIMApplication();
//        Map<String, String> urlVariables = new HashMap<>();
//        urlVariables.put("applicationId", appId);
//    	API_APPLICATIONS_DETAILS.replace("{applicationId}", appId);
        String response = HttpClientUtil.doHttpsGet(API_MANAGER_ENDPOINT+API_APPLICATIONS_DETAILS.replace("{applicationId}", appId), ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
    	if (!StringUtils.isEmpty(response)) {
    		result = JacksonUtil.readValue(response, APIMApplication.class);
    	}
        return result;
    }

    public APIMApplication createApplication(APIMApplication application){
    	APIMApplication result = new APIMApplication();
    	String response = HttpClientUtil.doHttpsPost(API_MANAGER_ENDPOINT+API_APPLICATIONS_CREATE, application,ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
    	if (!StringUtils.isEmpty(response)) {
    		result = JacksonUtil.readValue(response, APIMApplication.class);
    	}
        return result;
    }

    public APIMApplicationKey generateKey(String applicationId){
    	APIMApplicationKey result = new APIMApplicationKey();
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("validityTime", "900000000");
        requestBody.put("keyType", "PRODUCTION");
        requestBody.put("accessAllowDomains", new String[]{"ALL"});

    	String response = HttpClientUtil.doHttpsPost(API_MANAGER_ENDPOINT+API_APPLICATIONS_GENERATE_KEY + "?applicationId=" + applicationId, requestBody,ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
    	if (!StringUtils.isEmpty(response)) {
    		result = JacksonUtil.readValue(response, APIMApplicationKey.class);
    	}
        return result;
    }

    public APIMSubscription subscription(String apiIdentifier, String appId){
    	APIMSubscription result = new APIMSubscription();
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("tier", "Unlimited");
        requestBody.put("apiIdentifier", apiIdentifier);
        requestBody.put("applicationId", appId);
        String response = HttpClientUtil.doHttpsPost(API_MANAGER_ENDPOINT+API_SUBSCRIPTION_ADD, requestBody,ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
    	if (!StringUtils.isEmpty(response)) {
    		result = JacksonUtil.readValue(response, APIMSubscription.class);
    	}
        return result;
    }

    public APIMPageBean<APIMAPIResource> retrieveApiResource(String apiContext){
    	APIMPageBean<APIMAPIResource> result = new APIMPageBean<APIMAPIResource>(null,"","",0){};
//        ParameterizedTypeReference<APIMPageBean<APIMAPIResource>> responseType = new ParameterizedTypeReference<APIMPageBean<APIMAPIResource>>() {
//        };
        String response = HttpClientUtil.doHttpsGet(API_MANAGER_ENDPOINT+ API_APIRESOURCE_RETRIEVE + "?query=context://" + apiContext +"&limit=1000", ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
    	if (!StringUtils.isEmpty(response)) {
    		result = JacksonUtil.readValue(response, new TypeReference<APIMPageBean<APIMAPIResource>>() {});
    	}
        return result;
    }

    public boolean removeSubscription(String subscriptionId){
//        Map<String, String> urlVariables = new HashMap<>();
//        urlVariables.put("subscriptionId", subscriptionId);
        boolean response = HttpClientUtil.doHttpsDelete(API_MANAGER_ENDPOINT+API_SUBSCRIPTION_REMOVE.replace("{applicationId}", subscriptionId),ConfigurationProvider.ACCESS_TOKEN_SUBSCRIBE);
        return response;
    }
    
    public APIMSubscription subscripeByContext(String apiContext,String applicationId,boolean pxFlag){
   	 	 APIMSubscription apiSub = new APIMSubscription();
   	 	 //通过api自带接口查询api id以及申请服务，由于api 接口问题，需要判断查询出来的apiContext是否与申请出来的完全相同
   	 	 int position = pxFlag?2:1;
    	 for(APIMAPIResource apiDetail : retrieveApiResource(apiContext.split("/")[position]).getList())
		 {
			 logger.info("search "+apiDetail.getContext());
			 if(apiDetail.getContext().equals(apiContext))
			 {
				 apiSub = subscription(apiDetail.getId(),applicationId);
				 return apiSub;
			 }
			 
		 }
    	 return apiSub;
    }

	/** 
	 * @param projectId
	 * @return
	 */
	public String getAccessToken(String applicationId) {		
        String accessToken = "";
//		String applicationId = newApplication.getApplicationId();
	if (applicationId == null ) {
//		ret.setSuccess(false);
		logger.info( "创建Application失败.");
		return null;
	} else {			 
		 ArrayList<APIMApplicationKey> applicationKeys = getApplicationDetailsWithAppName(applicationId).getKeys();
		//判断是否已经生成api的token，没有则生成
		if(  applicationKeys.isEmpty())
		 {
			accessToken = generateKey(applicationId).getToken().getAccessToken();
			logger.info("generate token with appId:"+applicationId+", then get token:" + accessToken);
		}else {
//			Thread.sleep(1000);
			accessToken = applicationKeys.get(0).getToken().getAccessToken();
			logger.info("query token with appId:"+applicationId+", then get token:" + accessToken);
		}	
		return accessToken;
	}
    
	}
	
	public APIMApplication getApplication(String projectId){
		APIMApplication newApplication = new APIMApplication();
		try {
		if(retrieveApplications(projectId)!=null&&!retrieveApplications(projectId).getList().isEmpty()){
			 newApplication = retrieveApplications(projectId).getList().get(0);
//			 newApplication.setName(retrieveApplications(projectId).getList().get(0).getName());
//			 newApplication.setCallbackUrl(retrieveApplications(projectId).getList().get(0).getCallbackUrl());
//			 newApplication.setDescription(retrieveApplications(projectId).getList().get(0).getDescription());
//			 newApplication.setThrottlingTier(retrieveApplications(projectId).getList().get(0).getThrottlingTier());
		}
		else{
			APIMApplication application=new APIMApplication();
			application.setName(projectId);
			application.setCallbackUrl("http://my.server.com/callback");
			application.setDescription(projectId+" Application");
			application.setThrottlingTier("Unlimited");
			newApplication =  createApplication(application);
		}
	} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		return newApplication;
	}
	
	
}
