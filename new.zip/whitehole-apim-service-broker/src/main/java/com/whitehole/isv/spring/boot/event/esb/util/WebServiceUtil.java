package com.whitehole.isv.spring.boot.event.esb.util;
import static com.whitehole.isv.spring.boot.event.esb.configuration.ConfigurationProvider.WS_PORTALURL;

/**
 * Created by tony on 16-一月-22.
 */
public class WebServiceUtil {

    public static boolean isWebService(String serviceUrl,boolean pxFlag) {
    	if(pxFlag==true){
    		serviceUrl= "/px"+serviceUrl;
    	}
    	String[] webServiceUrls = WS_PORTALURL.split(",");
    	for(String url:webServiceUrls){
    		if(serviceUrl.equals(url)){
    			return true;
    		}
    		
    	}
//    		if(serviceUrl.equals(WS_DX_PORTALURL))
//    		{
//    			return true;
//    		}else if(serviceUrl.equals(WS_QBLD_PORTALURL))
//    		{
//    			return true;
//    		}else if(serviceUrl.equals(WS_ZZJGGL_PORTALURL))
//    		{
//    			return true;
//    		}else if(serviceUrl.equals(WS_FZZZJGGL_PORTALURL))
//    		{
//    			return true;
//    		}
//    		else if(serviceUrl.equals(WS_CRJGL_PORTALURL))
//    		{
//    			return true;
//    		}
    		
  
    		
    	
        return false;
    }

   
}
