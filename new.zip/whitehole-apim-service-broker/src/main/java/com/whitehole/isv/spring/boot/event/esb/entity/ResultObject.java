package com.whitehole.isv.spring.boot.event.esb.entity;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.json.JSONObject;

import java.util.Map;

/**
 * Created by tony on 16-一月-20.
 */
public class ResultObject {
    private boolean success;
    private String code;
    private String message;
    private Object result;

    public ResultObject() {
        this.setSuccess(false);
        this.setMessage("");
        this.setCode(String.valueOf(EventErrorCode.OK));
        this.setResult("");
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String toString() {
        ObjectNode node = JsonNodeFactory.instance.objectNode();
        node.put("success", this.isSuccess());
        node.put("message", this.getMessage());
        if(this.getResult() instanceof Map) {
            Map tmp = new ObjectMapper().convertValue(this.getResult(), Map.class);
            node.put("result", new JSONObject(tmp).toString());
        }
        else {
            node.put("result", this.getResult().toString());
        }
        node.put("code", this.getCode());

        return node.toString();
    }
}

