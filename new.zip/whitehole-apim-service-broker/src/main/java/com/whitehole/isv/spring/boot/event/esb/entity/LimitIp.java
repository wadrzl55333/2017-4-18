/**
 * 
 */
package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * @author zhangmenghao
 *
 */
public class LimitIp {
	private String id;
	private String url;
	private String ip;
	private Boolean status;
	private String subScriptionId;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}
	/**
	 * @param ip the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}
	/**
	 * @return the status
	 */
	public Boolean getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Boolean status) {
		this.status = status;
	}
	/**
	 * @return the subScriptionId
	 */
	public String getSubScriptionId() {
		return subScriptionId;
	}
	/**
	 * @param subScriptionId the subScriptionId to set
	 */
	public void setSubScriptionId(String subScriptionId) {
		this.subScriptionId = subScriptionId;
	}

	
}
