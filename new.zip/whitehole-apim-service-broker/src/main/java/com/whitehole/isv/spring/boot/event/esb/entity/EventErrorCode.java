package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * Created by tony on 16-一月-22.
 */
public enum EventErrorCode {
    OK(0), 
    SERVICE_NOT_VALID(10000), 
    FLAVOR_NOT_VALID(10001), 
    INSTANCE_NOT_EXIST(10002), 
    INSTANCE_NOT_READY(10003), 
    EVENT_DATA_NOT_VALID(10004), 
    HISTORY_DATA_NOT_VALID(10005), 
    CREATE_TASK_FAIL(10006), 
    QUERY_INSTANCE_FAIL(10007),
    ATTRIBUTE_ERROR(10008);
    private int value;

    private EventErrorCode(int value) {
            this.setValue(value);
    }

    /**
     * @return the value
     */
    public int getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(int value) {
        this.value = value;
    }
}
