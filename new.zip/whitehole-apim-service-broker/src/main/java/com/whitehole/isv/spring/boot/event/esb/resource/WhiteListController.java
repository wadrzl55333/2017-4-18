package com.whitehole.isv.spring.boot.event.esb.resource;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.whitehole.isv.spring.boot.event.esb.service.NginxConfigurationService;

/**
 * Created by zijian on 12/9/16.
 * 提供白名单相关接口给支撑平台门户调用
 * 用于支撑平台申请服务时，通知总线nginx修改对应配置，以达到限制IP访问的目的
 */
@RestController
@RequestMapping("/notification/whitelist")
public class WhiteListController {

    @Autowired
    private NginxConfigurationService nginxConfigurationService;

    @RequestMapping(method = RequestMethod.POST)
    public void updateWhiteList(Map<String, String> map) {

        //对应 nginx 配置中的location url
        String locationUrl = map.get("location");
        //对应 nginx 配置中的 allow
        String[] ips = map.get("ips").split(",");

        nginxConfigurationService.updateWhiteList(locationUrl, ips);

    }


}
