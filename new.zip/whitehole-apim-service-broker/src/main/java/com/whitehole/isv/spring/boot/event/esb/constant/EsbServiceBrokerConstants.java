package com.whitehole.isv.spring.boot.event.esb.constant;

/**
 * 基于Spring Boot开发的Isv Event示例Constants
 * Created by Jef_Wang on 2016/1/12.
 */
public class EsbServiceBrokerConstants {

    //事件类型_销毁事件
    public static final String EVENT_TYPE_CANCEL = "SUBSCRIPTION_CANCEL";

    //事件类型_变更事件
    public static final String EVENT_TYPE_CHANGE = "SUBSCRIPTION_CHANGE";

    //事件类型_通知事件
    public static final String EVENT_TYPE_NOTICE = "SUBSCRIPTION_NOTICE";

    //事件类型_订单事件(不分同步、异步)
    public static final String EVENT_TYPE_ORDER = "SUBSCRIPTION_ORDER";

    //事件类型_查询事件
    public static final String EVENT_TYPE_QUERY = "SUBSCRIPTION_QUERY";

    //事件类型_挂起事件
    public static final String EVENT_TYPE_SUSPEND = "SUBSCRIPTION_SUSPEND";

    //事件类型_激活事件
    public static final String EVENT_TYPE_ACTIVE = "SUBSCRIPTION_ACTIVE";

    //事件状态_正在执行状态
    public static final String EVENT_STATUS_PENDDING = "PENDDING";

    //事件状态_已通知ISV处理状态
    public static final String EVENT_STATUS_NOTIFIED = "NOTIFIED";

    //事件状态_执行失败状态
    public static final String EVENT_STATUS_FAILD = "FAILD";

    //事件状态_执行成功状态
    public static final String EVENT_STATUS_SUCCESS = "SUCCESS";

    //事件状态_等待ISV处理状态
    public static final String EVENT_STATUS_WAIT_FOR_RESULT = "WAIT_FOR_RESULT";

    //服务实例状态_激活状态
    public static final String SERVICE_INSTANCE_STATUS_ACTIVE = "ACTIVE";

    //服务实例状态_挂起状态
    public static final String SERVICE_INSTANCE_STATUS_SUSPENDED = "SUSPENDED";

    //服务实例状态_销毁状态
    public static final String SERVICE_INSTANCE_STATUS_CANCELLED = "CANCELLED";
}
