package com.whitehole.isv.spring.boot.event.esb.service;

import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.whitehole.isv.spring.boot.event.esb.entity.AmApi;
import com.whitehole.isv.spring.boot.event.esb.entity.LimitIp;
import com.whitehole.isv.spring.boot.event.esb.mapper.ApiMapper;
import com.whitehole.isv.spring.boot.event.esb.util.WebServiceUtil;

/**
 * 
 * @author zhangmenghao
 *
 */
@Service
public class ApiServiceForDatabase {
	
	@Autowired
	private ApiMapper apiMapper;
	
    private static Pattern reg = Pattern.compile("(:[\\w-]+)[/]{0,1}");
	
    public AmApi getApiByUrlPatternOrContext(String service,boolean pxFlag){
	     //对比带参数的urlPattern使用
	     String toCompairStr = new String();
	     String orgCompairStr = new String();
    	
	     String urlPattern = service;
	     AmApi reqApi = new AmApi();
	     Matcher strlist =  reg.matcher(service);    

	    //找到需要替代的变量(:xxx类型)，替换成%
		while(strlist.find())
		{             
			urlPattern = service.replace(strlist.group(1),"%");
	    }
    		if(WebServiceUtil.isWebService(service,pxFlag))
    		{
    			if(pxFlag==true){
    				service = "/px"+service;
    			}
    			reqApi=apiMapper.getApiByContext(service);
    			reqApi.setUrlPattern("");
    			return reqApi;
    		}
    	List<AmApi> apiList = apiMapper.getApiByUrlPattern(urlPattern);
    	if(apiList.size()==1){
    		return apiList.get(0);
    	}
    	else if (apiList.size()>1){
    		for(AmApi api:apiList){
    			toCompairStr =api.getUrlPattern().replace("{", "").replace("}", "");
    			orgCompairStr = service.replace(":", "");
    			if(toCompairStr.equals(orgCompairStr)){
    				if(pxFlag)
    				{
    					if(getApiContextByApiId(api.getApiId()).startsWith("/px")){
    						return api;
    					}
    				}else{
    					if(!getApiContextByApiId(api.getApiId()).startsWith("/px")){
    						return api;
    					}
    				}
    			}

    		}
    	}
    	return null;
    }
    
    public String getApiIdToByApplicationName(String projectId){
    	return apiMapper.getApiIdToByApplicationName(projectId);
    }
    
    public void addSubscription(String apiIdTo,String applicationIdTo,String uuid){
    	Date createdate = new Date();
    	apiMapper.addSubscription(apiIdTo,applicationIdTo,createdate,uuid);
    	return;
    }
    
    public boolean deleteSubscription(String uuid){
    	apiMapper.deleteSubscription(uuid);
    	return true;
    }
    
    public String getApiContextByApiId(String apiIdTo){
    	return apiMapper.getApiContextByApiId(apiIdTo);
    }
    
    public void addLimitIp(String service,String ipAdress,String subscriptionId){
    	apiMapper.addLimitIp(service,ipAdress,subscriptionId);
    	return;
    }
    
    public List<LimitIp> getLimitIp(){
    	return apiMapper.getLimitIp();
    }

	/**
	 * @param id
	 */
	public void changeLimitIpStatus(String id) {
		apiMapper.changeLimitIpStatus(id);
		return;
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param apiSubId
	 * @return
	 */
	public LimitIp getLimitIpBySubId(String apiSubId) {
		// TODO Auto-generated method stub
		
		return apiMapper.getLimitIpBySubId(apiSubId);
	}

	/**
	 * @param apiContext
	 * @return
	 */
	public AmApi getApiByContext(String apiContext) {
		// TODO Auto-generated method stub
		AmApi reqApi = new AmApi();
		reqApi= apiMapper.getApiByContext(apiContext);
		reqApi.setUrlPattern(apiMapper.getUrlPatternByApiId(reqApi.getApiId()));
		return reqApi;
	}
}
