/**
 * 
 */
package com.whitehole.isv.spring.boot.event.esb.util;

import java.io.InputStreamReader;
import java.io.LineNumberReader;

/**
 * @author zhangmenghao
 *
 */
public class LinuxOperationUtil {
	  public static Object exec(String cmd) {  
          try {  
              String[] cmdA = { "/bin/sh", "-c", cmd };  
              Process process = Runtime.getRuntime().exec(cmdA);  
              LineNumberReader br = new LineNumberReader(new InputStreamReader(  
                      process.getInputStream()));  
              StringBuffer sb = new StringBuffer();  
              String line;  
           while ((line = br.readLine()) != null) {  
                  System.out.println(line);  
                  sb.append(line).append("\n");  
              }  
              return sb.toString();  
          } catch (Exception e) {  
              e.printStackTrace();  
          }  
          return null;  
      }  
	  
	  public static void reloadNginx(){
		  String nginxReload = "/usr/local/nginx/sbin/nginx -s reload";
		  exec(nginxReload);
		  exec("echo success");
	  }
	  public static void copyWso2Data(){
		  String copyWso2Data = "sh copyWso2Data.sh";
		  exec(copyWso2Data);
		  exec("echo success");
	  }
//      public static void main(String[] args) {  
//          // TODO Auto-generated method stub  
//          String pwdString = exec("pwd").toString();  
//          String netsString = exec("netstat -nat|grep -i \"80\"|wc -l").toString();  
//             
//          System.out.println("==========获得值=============");  
//          System.out.println(pwdString);  
//          System.out.println(netsString);  
//      }  
     
}
