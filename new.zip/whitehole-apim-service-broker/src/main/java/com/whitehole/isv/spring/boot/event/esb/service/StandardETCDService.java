package com.whitehole.isv.spring.boot.event.esb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URI;
import java.util.concurrent.TimeoutException;

import javax.annotation.PostConstruct;


import mousio.etcd4j.EtcdClient;
import mousio.etcd4j.promises.EtcdResponsePromise;
import mousio.etcd4j.responses.EtcdAuthenticationException;
import mousio.etcd4j.responses.EtcdException;
import mousio.etcd4j.responses.EtcdKeysResponse;


@Service
public class StandardETCDService  {

    private EtcdClient client;

    @Value("${etcd.address}")
    private String[] serviceBrokers;

    @Value("${nginx.config.file.path}")
    private String nginxConfigPath;

 

    @PostConstruct
    public void initialize() {
        if (serviceBrokers == null || serviceBrokers.length <= 0) {
            return;
        }
        URI[] uris = new URI[serviceBrokers.length];

        for (int i = 0; i < serviceBrokers.length; i++) {
            uris[i] = URI.create(serviceBrokers[i]);
        }

        this.client = new EtcdClient(uris);
//        addEventWatch(appstackEventPrefix);
    }

    public void sendAndGet(String key, String value) {
        try {
            EtcdKeysResponse response = client.put(key, value).send().get();

            //log.info(">>>>>> Send ETCD message:: {}", response.node.value);

        } catch (EtcdException | IOException | EtcdAuthenticationException | TimeoutException e) {
            System.out.println("sendAndGet"+ e);
            
        }
    }

//    public void readFileAndSend() {
//
//        InputStreamReader inputReader = null;
//        BufferedReader bufferReader = null;
//        
//        try
//        {
//            InputStream inputStream = new FileInputStream(nginxConfigPath);
//            inputReader = new InputStreamReader(inputStream);
//            bufferReader = new BufferedReader(inputReader);
//             
//            // 读取一行
//            String line = null;
//            StringBuffer strBuffer = new StringBuffer();
//                 
//            while ((line = bufferReader.readLine()) != null)
//            {
//                strBuffer.append(line);
//            } 
//            sendAndGet("wso2nginx",strBuffer.toString());
//        }
//        catch (IOException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        finally
//        {
//        	
//        	try {
//        		inputReader.close();
//				bufferReader.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//        	
//        }
//    }
    /*
    * 监听方法
    * */
//    private void addEventWatch(String apiEventPrefix) {
//        try {
//            EtcdResponsePromise<EtcdKeysResponse> response = this.client.getDir(apiEventPrefix).recursive().waitForChange().send();
//
//            response.addListener(promise -> {
//                addEventWatch(apiEventPrefix);
//                if (response.getNow() != null) {
//                    EtcdKeysResponse.EtcdNode node = response.getNow().node;
//                    if (StringUtils.hasText(node.value)) {
//                        //应用堆栈的docker启动后 将容器关联到应用堆栈
//                        if (node.key.startsWith(appstackEventPrefix)) {
//                            try {
//                                handleFactory.handle(EventType.DockerEvent, response.get());
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        }
//                    }
//                }
//            });
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}
