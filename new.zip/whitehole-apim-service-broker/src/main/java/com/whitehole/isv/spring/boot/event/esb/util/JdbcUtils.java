package com.whitehole.isv.spring.boot.event.esb.util;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Created by zijian on 12/16/16.
 */
public class JdbcUtils {

    private static JdbcTemplate apimTemplate;

    private static JdbcTemplate portalTemplate;

    public static JdbcTemplate getApimTemplate(){

        if(apimTemplate == null){
            apimTemplate = new JdbcTemplate();
        }
        return apimTemplate;

    }
}
