package com.whitehole.isv.spring.boot.event.esb.entity;

/**
 * Created by tony on 16-一月-22.
 */
public enum EventStatus {
    PENDDING, NOTIFIED, FAILD, SUCCESS, WAIT_FOR_RESULT
}
