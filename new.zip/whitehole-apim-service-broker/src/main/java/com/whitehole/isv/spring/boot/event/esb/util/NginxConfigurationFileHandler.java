package com.whitehole.isv.spring.boot.event.esb.util;

import java.io.IOException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.github.odiszapc.nginxparser.NgxConfig;

/**
 * Created by zijian on 12/9/16.
 */
@Component
public class NginxConfigurationFileHandler {

    public static String nginxConfigurationFilePath;

    public static String nginxTemplateConfigurationFilePath;

    private static Logger logger = LogManager.getLogger(NginxConfigurationFileHandler.class);

    public static NgxConfig loadFile() throws IOException {
         return  NgxConfig.read(nginxConfigurationFilePath);
    }

    public static NgxConfig loadTemplateFile() throws IOException {
         return  NgxConfig.read(nginxTemplateConfigurationFilePath);
    }


    @Value("${nginx.config.file.template}")
    public void setNginxTemplateConfigurationFilePath(String nginxTemplateConfigurationFilePath) {
        this.nginxTemplateConfigurationFilePath = nginxTemplateConfigurationFilePath;
    }

    @Value("${nginx.config.file.path}")
    public void setNginxConfigurationFilePath(String nginxConfigurationFilePath) {
        this.nginxConfigurationFilePath = nginxConfigurationFilePath;
    }

//    NgxConfig conf = NgxConfig.read("/etc/nginx/nginx.conf");
//    NgxParam workers = conf.findParam("worker_processes");       // Ex.1
//    workers.getValue(); // "1"
//    NgxParam listen = conf.findParam("http", "server", "listen"); // Ex.2
//    listen.getValue(); // "8889"
//    List<NgxEntry> rtmpServers = conf.findAll(NgxConfig.BLOCK, "rtmp", "server"); // Ex.3
//    for (NgxEntry entry : rtmpServers) {
//        ((NgxBlock)entry).getName(); // "server"
//        ((NgxBlock)entry).findParam("application", "live"); // "on" for the first iter, "off" for the second one
//    }
}
