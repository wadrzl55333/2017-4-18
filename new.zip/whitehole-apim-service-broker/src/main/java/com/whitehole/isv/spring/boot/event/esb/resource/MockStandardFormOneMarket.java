package com.whitehole.isv.spring.boot.event.esb.resource;

import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 基于Spring Boot开发的Isv Event示例Resource
 * Created by Jef_Wang on 2016/1/12.
 */
@RestController
@RequestMapping("/mockStandard")
public class MockStandardFormOneMarket {

    private static Log logger = LogFactory.getLog(MockStandardFormOneMarket.class);
        @Autowired
        private ObjectMapper objectMapper;

    @RequestMapping(value = "/event-data/{type}", method = RequestMethod.POST)
    public ResponseEntity<JsonNode> nonInteractiveOrderEventData(@PathVariable String type, String instanceId, String status, String flavor) {
        String eventData = "";
        if(type.equals("async-order")) {
            eventData = "" +
                    "{" +
                    "  \"status\":  200," +
                    "  \"data\": {" +
                    "    \"type\": \"SUBSCRIPTION_ORDER\"," +
                    "    \"eventId\": \"" + UUID.randomUUID().toString() + "\"," +
                    "    \"marketplace\": {" +
                    "      \"partner\": \"Whitehole\"," +
                    "      \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "    }," +
                    "    \"creator\": {" +
                    "      \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "      \"email\": \"testerli@chinacloud.com.cn\"," +
                    "      \"firstName\": \"tester\"," +
                    "      \"lastName\": \"Li\"" +
                    "    }," +
                    "    \"payload\": {" +
                    "      \"tenant\": {" +
                    "        \"id\": \"d15bb36e-5fb5-11e0-8c3c-00262d2cda03\"," +
                    "        \"name\": \"ST_5100\"" +
                    "      }," +
                    "      \"order\": {" +
                    "        \"editionCode\": \"GET\"" +
                    "      }" +
                    "    }," +
                    "    \"callBackUrl\": \"http://10.64.202.96:8094/esb-service-broker/mockCustom/callback/process\"" +
                    "  }" +
                    "}";
        }
        else if(type.equals("cancel")) {
            eventData = "" +
                    "{" +
                    "  \"status\":  200," +
                    "  \"data\": {" +
                    "    \"type\": \"SUBSCRIPTION_CANCEL\"," +
                    "    \"eventId\": \"" + UUID.randomUUID().toString() + "\"," +
                    "    \"marketplace\": {" +
                    "      \"partner\": \"Whitehole\"," +
                    "      \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "    }," +
                    "    \"creator\": {" +
                    "      \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "      \"email\": \"testerli@chinacloud.com.cn\"," +
                    "      \"firstName\": \"tester\"," +
                    "      \"lastName\": \"Li\"" +
                    "    }," +
                    "    \"payload\": {" +
                    "        \"tenant\": {" +
                    "          \"id\": \"d15bb36e-5fb5-11e0-8c3c-00262d2cda03\"," +
                    "          \"name\": \"华云\"" +
                    "        }, " +
                    "      \"instance\": {" +
                    "       \"instanceId\": \"" + instanceId + "\"" +
                    "      }" +
                    "    }" +
                    "  }" +
                    "}";
        }
        else if (type.equals("query")) {
            eventData = "" +
                    "{" +
                    "  \"status\":  200," +
                    "  \"data\": {" +
                    "    \"type\": \"SUBSCRIPTION_QUERY\"," +
                    "    \"eventId\": \"" + UUID.randomUUID().toString() + "\"," +
                    "    \"marketplace\": {" +
                    "      \"partner\": \"Whitehole\"," +
                    "      \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "    }," +
                    "    \"creator\": {" +
                    "      \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "      \"email\": \"testerli@chinacloud.com.cn\"," +
                    "      \"firstName\": \"tester\"," +
                    "      \"lastName\": \"Li\"" +
                    "    }," +
                    "    \"payload\": {" +
                    "        \"tenant\": {" +
                    "          \"id\": \"d15bb36e-5fb5-11e0-8c3c-00262d2cda03\"," +
                    "          \"name\": \"华云\"" +
                    "        }, " +
                    "      \"instance\": {" +
                    "       \"instanceId\": \"" + instanceId + "\"" +
                    "      }" +
                    "    }," +
                    "    \"callBackUrl\": \"\"" +
                    "  }" +
                    "}";
        }
        else if (type.equals("suspend")) {
            eventData = "" +
                    "{" +
                    "  \"status\":  200," +
                    "  \"data\": {" +
                    "    \"type\": \"SUBSCRIPTION_SUSPEND\"," +
                    "    \"eventId\": \"" + UUID.randomUUID().toString() + "\"," +
                    "    \"marketplace\": {" +
                    "      \"partner\": \"Whitehole\"," +
                    "      \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "    }," +
                    "    \"creator\": {" +
                    "      \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "      \"email\": \"testerli@chinacloud.com.cn\"," +
                    "      \"firstName\": \"tester\"," +
                    "      \"lastName\": \"Li\"" +
                    "    }," +
                    "    \"payload\": {" +
                    "        \"tenant\": {" +
                    "          \"id\": \"d15bb36e-5fb5-11e0-8c3c-00262d2cda03\"," +
                    "          \"name\": \"华云\"" +
                    "        }, " +
                    "      \"instance\": {" +
                    "       \"instanceId\": \"" + instanceId + "\"" +
                    "      }" +
                    "    }," +
                    "    \"callBackUrl\":  \"http://127.0.0.1:8082/mir-service-broker/mockCustom/callback/process\"" +
                    "  }" +
                    "}";
        }
        else if (type.equals("active")) {
            eventData = "" +
                    "{" +
                    "  \"status\":  200," +
                    "  \"data\": {" +
                    "    \"type\": \"SUBSCRIPTION_ACTIVE\"," +
                    "    \"eventId\": \"" + UUID.randomUUID().toString() + "\"," +
                    "    \"marketplace\": {" +
                    "      \"partner\": \"Whitehole\"," +
                    "      \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "    }," +
                    "    \"creator\": {" +
                    "      \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "      \"email\": \"testerli@chinacloud.com.cn\"," +
                    "      \"firstName\": \"tester\"," +
                    "      \"lastName\": \"Li\"" +
                    "    }," +
                    "    \"payload\": {" +
                    "        \"tenant\": {" +
                    "          \"id\": \"d15bb36e-5fb5-11e0-8c3c-00262d2cda03\"," +
                    "          \"name\": \"华云\"" +
                    "        }, " +
                    "      \"instance\": {" +
                    "       \"instanceId\": \"" + instanceId + "\"" +
                    "      }" +
                    "    }," +
                    "    \"callBackUrl\":  \"http://127.0.0.1:8082/mir-service-broker/mockCustom/callback/process\"" +
                    "  }" +
                    "}";
        }
        else if(type.equals("change")) {
            //String flavor;
            if(flavor == null) {
                if (System.currentTimeMillis() % 2 == 0) {
                    flavor = "m.tiny";
                } else {
                    flavor = "m.tiny2";
                }
            }
            eventData = "{" +
                    "  \"type\": \"SUBSCRIPTION_CHANGE\"," +
                    "  \"marketplace\": {" +
                    "    \"partner\": \"Whitehole\"," +
                    "    \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "  }," +
                    "  \"creator\": {" +
                    "    \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "    \"email\": \"testerli@chinacloud.com.cn\"," +
                    "    \"firstName\": \"tester\"," +
                    "    \"lastName\": \"Li\"" +
                    "  }," +
                    "  \"payload\": {" +
                    "    \"instance\": {" +
                    "     \"instanceId\": \"" + instanceId + "\" " +
                    "    }" +
                    "    \"order\": {" +
                    "      \"editionCode\": \"" + flavor + "\"" +
                    "    } " +
                    "  }" +
                    "}";
        }
        else if(type.equals("notice")) {
            if(status == null) {
                if (System.currentTimeMillis() % 2 == 0) {
                    status = "DEACTIVATED";
                } else {
                    status = "ACTIVE";
                }
            }
            eventData = "{" +
                    "  \"type\": \"SUBSCRIPTION_NOTICE\"," +
                    "  \"marketplace\": {" +
                    "    \"partner\": \"Whitehole\"," +
                    "    \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "  }," +
                    "  \"creator\": {" +
                    "    \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "    \"email\": \"testerli@chinacloud.com.cn\"," +
                    "    \"firstName\": \"tester\"," +
                    "    \"lastName\": \"Li\"" +
                    "  }," +
                    "  \"payload\": {" +
                    "    \"instance\": {" +
                    "      \"instanceId\": \"" + instanceId + "\"," +
                    "      \"status\": \"ACTIVE\"" +
                    "    }," +
                    "    \"notice\": {" +
                    "      \"type\": \"" + status + "\"" +
                    "    }" +
                    "  }" +
                    "}";
        }
        else if(type.equals("sync-order")) {
            eventData = "{" +
                    "  \"type\": \"SUBSCRIPTION_ORDER\"," +
                    "  \"marketplace\": {" +
                    "    \"partner\": \"Whitehole\"," +
                    "    \"baseUrl\": \"https://www.wh-marketplace.com\"" +
                    "  }," +
                    "  \"creator\": {" +
                    "    \"id\": \"471a0c57-786c-46a1-93de-25a4f25e7d23\"," +
                    "    \"email\": \"testerli@chinacloud.com.cn\"," +
                    "    \"firstName\": \"tester\"," +
                    "    \"lastName\": \"Li\"" +
                    "  }," +
                    "  \"payload\": {" +
                    "    \"tenant\": {" +
                    "      \"projectId\": \"d15bb36e-5fb5-11e0-8c3c-00262d2cda03\"," +
                    "      \"name\": \"华云\"" +
                    "    }," +
                    "    \"order\": {" +
                    "      \"editionCode\": \"m.tiny\"" +
                    "    } " +
                    "  }," +
                    "  \"returnUrl\": \"http://127.0.0.1:8082/mir-service-broker/mockStandard/callback/process\"" +
                    "}";
        }

        logger.debug(eventData);
        JsonNode result;
            try {
                    result = objectMapper.readTree(eventData);
            } catch (Exception e) {
                result = this.getErrorResult(e);
            }
       return ResponseEntity.ok(result);
    }

    @RequestMapping(value = "/callback/process", method = RequestMethod.POST)
    public ResponseEntity<JsonNode> callbackProcess() {
        String errResult = "{" +
                "    \"success\": true," +
                "    \"message\": \"OneMarket已经收到您的异步处理结果\"" +
                "}";

        JsonNode result;
        try {
            result = objectMapper.readTree(errResult);
        } catch(Exception ex) {
            result = null;
        }
        return ResponseEntity.ok(result);
    }



    private JsonNode getErrorResult(Exception e) {
        String errResult = "{ " +
                "    \"success\": false," +
                //"    \"message\": \"" + JSONObject.quote(e.getMessage()) + "\"" +
                "    \"message\": \"" + "出现异常" + "\"" +
                " }";

        try {
            return objectMapper.readValue(errResult, JsonNode.class);
        } catch(Exception ex) {
            return null;
        }
    }


}
