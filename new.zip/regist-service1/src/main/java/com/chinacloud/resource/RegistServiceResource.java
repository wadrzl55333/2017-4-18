/**
 * 
 */
package com.chinacloud.resource;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Map;
import java.util.UUID;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.service.RegistServiceService;
import static com.chinacloud.configuration.ConfigurationProvider.TXT_PATH;
import static com.chinacloud.configuration.ConfigurationProvider.SERVICE_BROKER_ENDPOINT;

/**
 * @author zhangmenghao
 *
 */
@Controller
@RequestMapping("/test")
public class RegistServiceResource {
	
	@Autowired
	private RegistServiceService registServiceService;
	
//	private Logger logger = LogManager.getLogger(RegistServiceResource.class);
	
	@RequestMapping(value = "/aaa")
	 public boolean registSerivce(String[] arg) throws InterruptedException{
		 try {
		File readFile = new File(TXT_PATH);
//        FileOutputStream out=new FileOutputStream("D:\\对接系统\\移动警务接口\\移动警务接口\\移动警务接口脚本(示例)2.txt");
		InputStreamReader read = new InputStreamReader(new FileInputStream(readFile),"UTF-8");       
    	 BufferedReader reader = new BufferedReader(read);
//    	    PrintStream p=new PrintStream(out);
    	 System.out.println("以行为单位读取文件内容，一次读一整行：");
      
//			reader = new BufferedReader(new FileReader(readFile));
	
         String tempString = null;
         int line = 1;
         // 一次读入一行，直到读入null为文件结束
        
			while ((tempString = reader.readLine()) != null) {
				    System.out.println("line " + line + ": " + tempString);
		            String[] temp = tempString.split(" ");
		            String serviceName = temp[0];
		            String apiName = temp[0];
		            String apiUrl = temp[1];
		            String serviceDes = temp[2];
		            String context = UUID.randomUUID().toString();
		            String serviceEndpoint = temp[3];
		            String serviceEventUrl = SERVICE_BROKER_ENDPOINT
		            		+ "/apim-service-broker/v2/event/"+context+"/v1?url={eventUrl}";
//		            String serviceEventUrl = temp[4];
		            String method = temp[5];
//		            String context = temp[6];
			   		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw(serviceName,serviceDes);
					String serviceId = result.getData().get("serviceId").toString();
					String wso2Id = registServiceService.saveServiceForWso2(serviceId,context,apiName,method,apiUrl).getData().get("id").toString();
					registServiceService.saveServiceKey(serviceId,serviceEventUrl);
			        registServiceService.saveServiceEndpoint(serviceId, wso2Id,context,apiName,serviceEndpoint,method,apiUrl);
			        Thread.sleep(2000);
			        System.out.println(apiName + "regists success");
			 
		} 
			}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return true;
//		ResponseObject<Map<String, Object>> result = registServiceService.RegistServiceOverviw();
//		String serviceId = result.getData().get("serviceId").toString();
//		String wso2Id = registServiceService.saveServiceForWso2(serviceId).getData().get("id").toString();
//		registServiceService.saveServiceKey(serviceId);
//        registServiceService.saveServiceEndpoint(serviceId, wso2Id);
//		return result;
	 }
}
