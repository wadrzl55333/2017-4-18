package com.chinacloud.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by zijian on 10/10/16.
 */
@Component
public class ConfigurationProvider {

	public static String HEADER;
	
    public static String SERVICE_CATEGORY_ID;
    public static String WHITEHOLE_ENDPOINT;
    public static String CREATOR_ID;
    public static String CREATOR_NAME;

    public static String PROJECT_ID;
    public static Integer APP_ID;
    public static String APP_NAME;
    public static String TXT_PATH;
   
    public static String SERVICE_BROKER_ENDPOINT;
    
    


    @Value("${serviceRegist.header}")
    public void setHeader(String header) {
    	HEADER = header;
    }
    
//    @Value("${serviceRegist.header}")
//    public void setWso2Carbon(String wso2Carbon) {
//    	WSO2CARBON = wso2Carbon;
//    }
    @Value("${serviceRegist.serviceCategoryId}")
    public void setServiceCategoryId(String serviceCategoryId) {
    	SERVICE_CATEGORY_ID = serviceCategoryId;
    }
    @Value("${whiteholeEndpoint}")
    public void setWhiteholeEndpoint(String whiteholeEndpoint) {
    	WHITEHOLE_ENDPOINT = whiteholeEndpoint;
    }
    
    @Value("${serviceBrokerEndpoint}")
    public void setServiceBrokerEndpoint(String serviceBrokerEndpoint) {
    	SERVICE_BROKER_ENDPOINT = serviceBrokerEndpoint;
    }
    
    @Value("${serviceRegist.creatorId}")
    public void setCreatorId(String creatorId) {
    	CREATOR_ID = creatorId;
    }
    @Value("${serviceRegist.creatorName}")
    public void setCreatorName(String creatorName) {
    	CREATOR_NAME = creatorName;
    }
    @Value("${serviceRegist.projectId}")
    public void setProjectId(String projectId) {
    	PROJECT_ID = projectId;
    }
    @Value("${serviceRegist.appId}")
    public void seAppId(String appId) {
    	APP_ID = Integer.valueOf(appId.replace("a",""));
    }
    @Value("${serviceRegist.appName}")
    public void setAppName(String appName) {
    	APP_NAME = appName;
    }
    @Value("${serviceRegist.txtPath}")
    public void setTxtPath(String txtPath) {
    	TXT_PATH = txtPath;
    }
    
    
}
