package com.chinacloud.dto;

import javax.validation.constraints.Size;

/**
 * 服务管理_注册新服务_接入参数_自定义事件请求参数
 * Created by Jef_Wang on 2016/1/18.
 */
public class CustomEventDto {

    //自定义事件ID
    private String customEventId;

    //自定义事件名称
    @Size(max=40)
    private String customEventName;

    //自定义事件参数
    @Size(max=40)
    private String customEventType;

    public String getCustomEventId() {
        return customEventId;
    }

    public void setCustomEventId(String customEventId) {
        this.customEventId = customEventId;
    }

    public String getCustomEventName() {
        return customEventName;
    }

    public void setCustomEventName(String customEventName) {
        this.customEventName = customEventName;
    }

    public String getCustomEventType() {
        return customEventType;
    }

    public void setCustomEventType(String customEventType) {
        this.customEventType = customEventType;
    }
}
