package com.chinacloud.dto;


import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * 服务管理_注册新服务_接入参数请求参数
 * Created by Jef_Wang on 2016/1/18.
 */
public class KeyDto {

    //服务ID
    private String serviceId;

    private String serviceName;

    private Date customVersion;

    public Date getCustomVersion() {
        return customVersion;
    }

    public void setCustomVersion(Date customVersion) {
        this.customVersion = customVersion;
    }

    //服务通知地址
    @NotNull
    @Size(max=2048)
    private String notificationUrl;

    //自定义事件
    List<CustomEventDto> customEvents;

    //信息完整度
    private String infoIntegrity;

    public String getInfoIntegrity() {
        return infoIntegrity;
    }

    public void setInfoIntegrity(String infoIntegrity) {
        this.infoIntegrity = infoIntegrity;
    }

    public List<CustomEventDto> getCustomEvents() {
        return customEvents;
    }

    public void setCustomEvents(List<CustomEventDto> customEvents) {
        this.customEvents = customEvents;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getNotificationUrl() {
        return notificationUrl;
    }

    public void setNotificationUrl(String notificationUrl) {
        this.notificationUrl = notificationUrl;
    }

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
    
    
}
