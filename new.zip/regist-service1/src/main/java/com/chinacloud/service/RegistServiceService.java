/**
 * 
 */
package com.chinacloud.service;



import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.chinacloud.common.ResponseObject;
import com.chinacloud.dto.ApiServiceDto;
import com.chinacloud.dto.BusinessInformationDto;
import com.chinacloud.dto.CorsConfigurationDto;
import com.chinacloud.dto.KeyDto;
import com.chinacloud.dto.ServiceOverviewDto;
import static com.chinacloud.configuration.ConfigurationProvider.*;



/**
 * @author zhangmenghao
 *
 */


@Service
public class RegistServiceService {
	
	private RestTemplate restTemplate = new RestTemplate();
	
	
	
	public ResponseObject<Map<String, Object>> RegistServiceOverviw(String serviceName,String serviceDes){
        ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
        };
		String result = "";
		ServiceOverviewDto serviceOverviewDto = new ServiceOverviewDto();
		serviceOverviewDto.setServiceId(null);
		serviceOverviewDto.setServiceName(serviceName);
		serviceOverviewDto.setServiceCategoryId(SERVICE_CATEGORY_ID);
		serviceOverviewDto.setServiceDescription(serviceDes);
		serviceOverviewDto.setCreatorId(CREATOR_ID);
		serviceOverviewDto.setProvider(CREATOR_NAME);
		serviceOverviewDto.setServiceType(1);
//		serviceOverviewDto.setAppId(APP_ID);
//		serviceOverviewDto.setAppName(APP_NAME);
		serviceOverviewDto.setApiType("REST");
		serviceOverviewDto.setProjectId(PROJECT_ID);

	 	HttpHeaders headers = new HttpHeaders();
   	 	headers.add("X-Auth-Token", HEADER);

		HttpEntity httpEntity = new HttpEntity(serviceOverviewDto,headers);
		ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate.exchange(WHITEHOLE_ENDPOINT
				+ "/business/service/saveServiceOverview", POST, httpEntity,responseType);
		return response.getBody();
	}
	
	public ResponseObject<Map<String, Object>> saveServiceForWso2(String serviceId,String context,String apiName,String method, String apiUrl){
		 ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
	        };
//	        String context = "aaabbbccc";
	        ApiServiceDto apiServiceDto = new ApiServiceDto();
	        apiServiceDto.setContext(context);
	        apiServiceDto.setIsDefaultVersion(false);
	        List<String> transport = new ArrayList();
	        transport.add("http");
	        transport.add("https");
	        List<String> tiers = new ArrayList();
	        tiers.add("Unlimited");
	        apiServiceDto.setTransport(transport);
	        apiServiceDto.setTiers(tiers);
	        apiServiceDto.setEndpointConfig("{\"production_endpoints\":{\"url\":null,\"config\":null},\"sandbox_endpoints\":{\"url\":null,\"config\":null},\"endpoint_type\":\"http\"}");
	        apiServiceDto.setName(apiName);
	        apiServiceDto.setVersion("v1");
	        apiServiceDto.setApiDefinition("{\"swagger\":\"2.0\",\"paths\":{\"/"
	        		+ apiUrl
	        		+ "\":{\""
	        		+ method
	        		+ "\":{\"responses\":{\"200\":{\"description\":\"\"}},\"xAuthType\":\"Application & Application User\",\"description\":\"\",\"produces\":[\"application/json\"],\"consumes\":[\"application/json\"],\"summary\":\"\",\"inputname\":\"\",\"parameterDisplay\":false,\"parameters\":[]}}}}");
	        
	        
	   	 	HttpHeaders headers = new HttpHeaders();
	   	 	headers.add("X-Auth-Token", HEADER);
			HttpEntity httpEntity = new HttpEntity(apiServiceDto,headers);
	    	ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate.exchange(WHITEHOLE_ENDPOINT
	    			+ "/business/apiservices/"+serviceId+"/apis/"
	    					+ method, POST, httpEntity,responseType);
			return response.getBody();
	}
		
	public ResponseObject<Map<String, Object>> saveServiceKey(String serviceId,String serviceEventUrl){
		 ParameterizedTypeReference<ResponseObject<Map<String, Object>>> responseType = new ParameterizedTypeReference<ResponseObject<Map<String, Object>>>() {
	        };
	        
	        KeyDto keyDto = new KeyDto();
	        keyDto.setServiceId(serviceId);
	        keyDto.setNotificationUrl(serviceEventUrl);
	        
	        
		 	HttpHeaders headers = new HttpHeaders();
	   	 	headers.add("X-Auth-Token", HEADER);

			HttpEntity httpEntity = new HttpEntity(keyDto,headers);
	    	ResponseEntity<ResponseObject<Map<String, Object>>> response = restTemplate.exchange(WHITEHOLE_ENDPOINT
	    			+ "/business/service/saveServiceKey", POST, httpEntity,responseType);
			return response.getBody();
	}
	
	public ResponseObject<ApiServiceDto> saveServiceEndpoint(String serviceId,String wso2Id, String context, String apiName, String serviceEndpoint,String method, String apiUrl){
		 ParameterizedTypeReference<ResponseObject<ApiServiceDto>> responseType = new ParameterizedTypeReference<ResponseObject<ApiServiceDto>>() {
	        };
//	        String context = "aaabbbccc";
	        ApiServiceDto apiServiceDto = new ApiServiceDto();
	        apiServiceDto.setId(wso2Id);
	        apiServiceDto.setName(apiName);
	        apiServiceDto.setContext(context);
	        apiServiceDto.setVersion("v1");
	        apiServiceDto.setProvider("admin");
	        apiServiceDto.setApiDefinition("{\"swagger\":\"2.0\",\"paths\":{\"/"
	        		+ apiUrl
	        		+ "\":{\""
	        		+ method
	        		+ "\":{\"responses\":{\"200\":{\"description\":\"\"}},\"xAuthType\":\"Application & Application User\",\"description\":\"\",\"produces\":[\"application/json\"],\"consumes\":[\"application/json\"],\"summary\":\"\",\"inputname\":\"\",\"parameterDisplay\":false,\"parameters\":[]}}}}");
	        apiServiceDto.setStatus("CREATED");
	        apiServiceDto.setCacheTimeout(0);
	        List<String> transport = new ArrayList();
	        transport.add("http");
	        transport.add("https");
	        List<String> tiers = new ArrayList();
	        tiers.add("Unlimited");
	        List<String> Tags = new ArrayList();
	        apiServiceDto.setTransport(transport);
	        apiServiceDto.setTags(Tags);
	        apiServiceDto.setTiers(tiers);
	        apiServiceDto.setEndpointConfig("{\"production_endpoints\":{\"url\":\""
	        		+ serviceEndpoint
	        		+ "\",\"config\":null},\"sandbox_endpoints\":{\"url\":\""
	        		+ serviceEndpoint
	        		+ "\",\"config\":null},\"endpoint_type\":\"http\"}");
	        apiServiceDto.setGatewayEnvironments("Production and Sandbox");
	        apiServiceDto.setIsDefaultVersion(false);
	        CorsConfigurationDto corsConfiguration = new CorsConfigurationDto();
	        
	        
	        corsConfiguration.setAccessControlAllowCredentials(false);
	        corsConfiguration.setCorsConfigurationEnabled(true);
	        List<String> accessControlAllowHeaders = new ArrayList();
	        accessControlAllowHeaders.add("authorization");
	        accessControlAllowHeaders.add("Access-Control-Allow-Origin");
	        accessControlAllowHeaders.add("Content-Type");
	        accessControlAllowHeaders.add("SOAPAction");
	        

	        List<String> accessControlAllowOrigins = new ArrayList();
	        accessControlAllowOrigins.add("*");
	     
	      
	        List<String> accessControlAllowMethods = new ArrayList();
	        accessControlAllowMethods.add("GET");
	        accessControlAllowMethods.add("PUT");
	        accessControlAllowMethods.add("POST");
	        accessControlAllowMethods.add("DELETE");
	        accessControlAllowMethods.add("PATCH");
	        accessControlAllowMethods.add("OPTIONS");
	        
	        corsConfiguration.setAccessControlAllowHeaders(accessControlAllowHeaders);
	        corsConfiguration.setAccessControlAllowMethods(accessControlAllowMethods);
	        corsConfiguration.setAccessControlAllowOrigins(accessControlAllowOrigins);
	        
	        BusinessInformationDto businessInformation =new BusinessInformationDto();
	        
	        
	        apiServiceDto.setBusinessInformation(businessInformation);
	        apiServiceDto.setCorsConfiguration(corsConfiguration);
	      
	 
	        
	        
		 	HttpHeaders headers = new HttpHeaders();
	   	 	headers.add("X-Auth-Token", HEADER);

			HttpEntity httpEntity = new HttpEntity(apiServiceDto,headers);
	    	ResponseEntity<ResponseObject<ApiServiceDto>> response = restTemplate.exchange(WHITEHOLE_ENDPOINT
	    			+ "/business/apiservices/"
	    			+ serviceId
	    			+ "/apis/"
	    			+ wso2Id
	    			+ "/get", PUT, httpEntity,responseType);
			return response.getBody();
	}
	
}
